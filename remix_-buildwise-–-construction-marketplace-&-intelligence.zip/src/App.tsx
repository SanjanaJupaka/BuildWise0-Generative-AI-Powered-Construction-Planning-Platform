import React, { useState, useEffect } from 'react';
import { User, UserRole, Project } from './types';
import Login from './components/Auth';
import CustomerDashboard from './components/CustomerDashboard';
import ContractorDashboard from './components/ContractorDashboard';
import { Marketplace, ContractorList } from './components/Marketplace';
import { Building2, LogOut, LayoutDashboard, ShoppingCart, Users, HardHat } from 'lucide-react';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'marketplace' | 'contractors'>('dashboard');
  const [selectedContractorId, setSelectedContractorId] = useState<number | null>(null);

  useEffect(() => {
    fetch('/api/me')
      .then(res => res.json())
      .then(data => {
        setUser(data.user);
        setLoading(false);
      });
  }, []);

  const handleLogout = async () => {
    await fetch('/api/logout', { method: 'POST' });
    setUser(null);
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;

  if (!user) return <Login onLogin={setUser} />;

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 text-white flex flex-col sticky top-0 h-screen">
        <div className="p-8">
          <div className="flex items-center gap-2 mb-10">
            <Building2 className="w-6 h-6 text-blue-500" />
            <span className="text-xl font-black tracking-tight">BUILD<span className="text-blue-500">WISE</span></span>
          </div>

          <nav className="space-y-2">
            <button 
              onClick={() => setActiveTab('dashboard')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all ${activeTab === 'dashboard' ? 'bg-blue-700 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}
            >
              <LayoutDashboard className="w-4 h-4" /> Dashboard
            </button>
            {user.role === 'Customer' && (
              <>
                <button 
                  onClick={() => setActiveTab('contractors')}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all ${activeTab === 'contractors' ? 'bg-blue-700 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}
                >
                  <Users className="w-4 h-4" /> Contractors
                </button>
                <button 
                  onClick={() => setActiveTab('marketplace')}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all ${activeTab === 'marketplace' ? 'bg-blue-700 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}
                >
                  <ShoppingCart className="w-4 h-4" /> Marketplace
                </button>
              </>
            )}
          </nav>
        </div>

        <div className="mt-auto p-8 border-t border-slate-800">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center font-bold">
              {user.name[0]}
            </div>
            <div className="overflow-hidden">
              <p className="text-xs font-bold truncate">{user.name}</p>
              <p className="text-[10px] text-blue-400 font-bold uppercase tracking-widest">{user.role}</p>
            </div>
          </div>
          <button 
            onClick={handleLogout}
            className="flex items-center gap-2 text-xs font-bold text-slate-500 hover:text-rose-400 transition-colors"
          >
            <LogOut className="w-4 h-4" /> Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-8">
        {activeTab === 'dashboard' && (
          user.role === 'Customer' ? (
            <CustomerDashboard 
              user={user} 
              initialContractorId={selectedContractorId} 
              onModalClose={() => setSelectedContractorId(null)}
            />
          ) : (
            <ContractorDashboard user={user} />
          )
        )}
        {activeTab === 'marketplace' && <Marketplace />}
        {activeTab === 'contractors' && (
          <ContractorList onSelect={(id) => {
            setSelectedContractorId(id);
            setActiveTab('dashboard');
          }} />
        )}
      </main>
    </div>
  );
}
