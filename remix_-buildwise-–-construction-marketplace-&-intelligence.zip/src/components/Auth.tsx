import React, { useState } from 'react';
import { User, UserRole } from '../types';
import { Building2, User as UserIcon, ShieldCheck } from 'lucide-react';

interface Props {
  onLogin: (user: User) => void;
}

export default function Auth({ onLogin }: Props) {
  const [isRegister, setIsRegister] = useState(false);
  const [role, setRole] = useState<UserRole>('Customer');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [budget, setBudget] = useState('');
  const [specialization, setSpecialization] = useState('');
  const [bio, setBio] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const endpoint = isRegister ? '/api/register' : '/api/login';
    const body = isRegister ? { name, email, password, role, budget_range: budget, specialization, bio } : { email, password };

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      
      if (isRegister) {
        setIsRegister(false);
        alert('Registration successful! Please login.');
      } else {
        onLogin(data.user);
      }
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="max-w-md w-full space-y-8 bg-white p-10 rounded-3xl shadow-2xl">
        <div className="text-center">
          <div className="inline-flex bg-blue-700 p-3 rounded-2xl mb-4">
            <Building2 className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">BUILD<span className="text-blue-700">WISE</span></h1>
          <p className="text-slate-500 font-medium mt-2">
            {isRegister ? 'Create your account' : 'Sign in to your account'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {isRegister && (
            <>
              <div className="grid grid-cols-2 gap-2 mb-4">
                <button
                  type="button"
                  onClick={() => setRole('Customer')}
                  className={`p-3 rounded-xl border-2 flex flex-col items-center gap-1 transition-all ${role === 'Customer' ? 'border-blue-500 bg-blue-50' : 'border-slate-100'}`}
                >
                  <UserIcon className="w-5 h-5" />
                  <span className="text-xs font-bold">Customer</span>
                </button>
                <button
                  type="button"
                  onClick={() => setRole('Contractor')}
                  className={`p-3 rounded-xl border-2 flex flex-col items-center gap-1 transition-all ${role === 'Contractor' ? 'border-blue-500 bg-blue-50' : 'border-slate-100'}`}
                >
                  <ShieldCheck className="w-5 h-5" />
                  <span className="text-xs font-bold">Contractor</span>
                </button>
              </div>
              <input
                type="text"
                placeholder="Full Name"
                className="w-full p-3 rounded-xl border border-slate-200"
                value={name}
                onChange={e => setName(e.target.value)}
                required
              />
              {role === 'Customer' && (
                <input
                  type="text"
                  placeholder="Budget Range (e.g. 5M - 10M)"
                  className="w-full p-3 rounded-xl border border-slate-200"
                  value={budget}
                  onChange={e => setBudget(e.target.value)}
                />
              )}
              {role === 'Contractor' && (
                <>
                  <input
                    type="text"
                    placeholder="Specialization (e.g. Luxury Residential)"
                    className="w-full p-3 rounded-xl border border-slate-200"
                    value={specialization}
                    onChange={e => setSpecialization(e.target.value)}
                    required
                  />
                  <textarea
                    placeholder="Tell us about your experience..."
                    className="w-full p-3 rounded-xl border border-slate-200 min-h-[100px]"
                    value={bio}
                    onChange={e => setBio(e.target.value)}
                    required
                  />
                  <input
                    type="text"
                    placeholder="Budget Range (e.g. 1M - 50M)"
                    className="w-full p-3 rounded-xl border border-slate-200"
                    value={budget}
                    onChange={e => setBudget(e.target.value)}
                    required
                  />
                </>
              )}
            </>
          )}
          <input
            type="email"
            placeholder="Email Address"
            className="w-full p-3 rounded-xl border border-slate-200"
            value={email}
            onChange={e => setEmail(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Password"
            className="w-full p-3 rounded-xl border border-slate-200"
            value={password}
            onChange={e => setPassword(e.target.value)}
            required
          />
          
          {error && <p className="text-rose-500 text-xs font-bold">{error}</p>}

          <button
            type="submit"
            className="w-full bg-blue-700 text-white font-bold py-3 rounded-xl hover:bg-blue-800 transition-all"
          >
            {isRegister ? 'Register' : 'Sign In'}
          </button>
        </form>

        <div className="text-center">
          <button
            onClick={() => setIsRegister(!isRegister)}
            className="text-sm font-bold text-blue-700 hover:underline"
          >
            {isRegister ? 'Already have an account? Sign In' : "Don't have an account? Register"}
          </button>
        </div>
      </div>
    </div>
  );
}
